package com.pack.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcMappingApplication.class, args);
	}

}
