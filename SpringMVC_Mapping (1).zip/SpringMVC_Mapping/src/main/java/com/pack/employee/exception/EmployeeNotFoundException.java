package com.pack.employee.exception;

public class EmployeeNotFoundException extends Exception{
 
	public String toString()
	{
		
		return "Employee Id not found";
	}
}
